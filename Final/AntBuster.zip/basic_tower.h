#pragma once
#include "tower.h"
class basic_tower : public Tower
{
public:
	basic_tower();
};

